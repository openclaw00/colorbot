/*
  Color Key Trigger GUI - Windows 10/11, single-file Win32 C++20.

  What it does:
    Watches a small box in the center of the screen. If it sees the selected
    color within the selected tolerance, it presses and releases a keyboard key.

  How to build from "Developer Command Prompt for VS":
    cl /std:c++20 /O2 /EHsc /DUNICODE /D_UNICODE color_trigger_gui.cpp user32.lib gdi32.lib comdlg32.lib /link /SUBSYSTEM:WINDOWS

  How to use:
    1. Run color_trigger_gui.exe.
    2. Pick the color, size, key, and timing values.
    3. Click Start.
    4. Click Stop or close the window to stop safely.

  No external libraries. No console. No logs.
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <cwctype>
#include <mutex>
#include <random>
#include <string>
#include <thread>

// ----------------------------- Defaults -----------------------------

static constexpr int DEFAULT_CAPTURE_W = 40;
static constexpr int DEFAULT_CAPTURE_H = 40;
static constexpr int DEFAULT_TARGET_R = 255;
static constexpr int DEFAULT_TARGET_G = 230;
static constexpr int DEFAULT_TARGET_B = 0;
static constexpr int DEFAULT_TOLERANCE = 35;
static constexpr wchar_t DEFAULT_KEY[] = L"F";
static constexpr int DEFAULT_COOLDOWN_MS = 250;
static constexpr int DEFAULT_PRE_MIN_MS = 25;
static constexpr int DEFAULT_PRE_MAX_MS = 90;
static constexpr int DEFAULT_HOLD_MIN_MS = 35;
static constexpr int DEFAULT_HOLD_MAX_MS = 120;
static constexpr int DEFAULT_REPEAT_MIN_MS = 40;
static constexpr int DEFAULT_REPEAT_MAX_MS = 180;
static constexpr int DEFAULT_LOOP_MIN_MS = 1;
static constexpr int DEFAULT_LOOP_MAX_MS = 4;
static constexpr int DEFAULT_MIN_MATCHING_PIXELS = 3;

// ----------------------------- Control IDs -----------------------------

enum ControlId {
    IDC_CAPTURE_W = 1001,
    IDC_CAPTURE_H,
    IDC_TARGET_R,
    IDC_TARGET_G,
    IDC_TARGET_B,
    IDC_TOLERANCE,
    IDC_KEY,
    IDC_COOLDOWN,
    IDC_PRE_MIN,
    IDC_PRE_MAX,
    IDC_HOLD_MIN,
    IDC_HOLD_MAX,
    IDC_REPEAT_MIN,
    IDC_REPEAT_MAX,
    IDC_LOOP_MIN,
    IDC_LOOP_MAX,
    IDC_MIN_PIXELS,
    IDC_COLOR_PICKER,
    IDC_START,
    IDC_STOP,
    IDC_APPLY,
    IDC_STATUS,
    IDC_PREVIEW,
    IDC_PRIMARY
};

struct Config {
    int capture_w = DEFAULT_CAPTURE_W;
    int capture_h = DEFAULT_CAPTURE_H;
    int r = DEFAULT_TARGET_R;
    int g = DEFAULT_TARGET_G;
    int b = DEFAULT_TARGET_B;
    int tolerance = DEFAULT_TOLERANCE;
    WORD vk = 'F';
    int cooldown_ms = DEFAULT_COOLDOWN_MS;
    int pre_min_ms = DEFAULT_PRE_MIN_MS;
    int pre_max_ms = DEFAULT_PRE_MAX_MS;
    int hold_min_ms = DEFAULT_HOLD_MIN_MS;
    int hold_max_ms = DEFAULT_HOLD_MAX_MS;
    int repeat_min_ms = DEFAULT_REPEAT_MIN_MS;
    int repeat_max_ms = DEFAULT_REPEAT_MAX_MS;
    int loop_min_ms = DEFAULT_LOOP_MIN_MS;
    int loop_max_ms = DEFAULT_LOOP_MAX_MS;
    int min_matching_pixels = DEFAULT_MIN_MATCHING_PIXELS;
    bool primary_monitor = true;
};

struct CaptureBuffer {
    HDC screen_dc = nullptr;
    HDC memory_dc = nullptr;
    HBITMAP bitmap = nullptr;
    HGDIOBJ old_bitmap = nullptr;
    uint8_t* pixels = nullptr;
    int width = 0;
    int height = 0;

    bool init(int w, int h) {
        destroy();
        width = w;
        height = h;

        screen_dc = GetDC(nullptr);
        if (!screen_dc) return false;

        memory_dc = CreateCompatibleDC(screen_dc);
        if (!memory_dc) return false;

        BITMAPINFO bmi{};
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = width;
        bmi.bmiHeader.biHeight = -height; // top-down 32-bit DIB
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        bitmap = CreateDIBSection(memory_dc, &bmi, DIB_RGB_COLORS,
                                  reinterpret_cast<void**>(&pixels), nullptr, 0);
        if (!bitmap || !pixels) return false;

        old_bitmap = SelectObject(memory_dc, bitmap);
        return old_bitmap != nullptr;
    }

    bool capture(int x, int y) {
        return BitBlt(memory_dc, 0, 0, width, height, screen_dc, x, y,
                      SRCCOPY | CAPTUREBLT) != 0;
    }

    void destroy() {
        if (memory_dc && old_bitmap) SelectObject(memory_dc, old_bitmap);
        if (bitmap) DeleteObject(bitmap);
        if (memory_dc) DeleteDC(memory_dc);
        if (screen_dc) ReleaseDC(nullptr, screen_dc);
        screen_dc = nullptr;
        memory_dc = nullptr;
        bitmap = nullptr;
        old_bitmap = nullptr;
        pixels = nullptr;
        width = 0;
        height = 0;
    }

    ~CaptureBuffer() {
        destroy();
    }
};

static HWND g_main = nullptr;
static std::mutex g_config_mutex;
static Config g_config;
static std::atomic<bool> g_running{false};
static std::thread g_worker;

static HWND g_capture_w = nullptr;
static HWND g_capture_h = nullptr;
static HWND g_target_r = nullptr;
static HWND g_target_g = nullptr;
static HWND g_target_b = nullptr;
static HWND g_tolerance = nullptr;
static HWND g_key = nullptr;
static HWND g_cooldown = nullptr;
static HWND g_pre_min = nullptr;
static HWND g_pre_max = nullptr;
static HWND g_hold_min = nullptr;
static HWND g_hold_max = nullptr;
static HWND g_repeat_min = nullptr;
static HWND g_repeat_max = nullptr;
static HWND g_loop_min = nullptr;
static HWND g_loop_max = nullptr;
static HWND g_min_pixels = nullptr;
static HWND g_status = nullptr;
static HWND g_preview = nullptr;
static HWND g_primary = nullptr;
static HBRUSH g_preview_brush = nullptr;

static int clamp_int(int v, int lo, int hi) {
    return std::max(lo, std::min(v, hi));
}

static int rand_range(std::mt19937& rng, int lo, int hi) {
    if (hi <= lo) return lo;
    std::uniform_int_distribution<int> dist(lo, hi);
    return dist(rng);
}

static void set_text(HWND hwnd, const wchar_t* text) {
    SetWindowTextW(hwnd, text);
}

static void set_int(HWND hwnd, int value) {
    wchar_t buf[32]{};
    wsprintfW(buf, L"%d", value);
    SetWindowTextW(hwnd, buf);
}

static int get_int(HWND hwnd, int fallback, int lo, int hi) {
    wchar_t buf[64]{};
    GetWindowTextW(hwnd, buf, 64);
    wchar_t* end = nullptr;
    const long value = wcstol(buf, &end, 10);
    if (end == buf) return fallback;
    return clamp_int(static_cast<int>(value), lo, hi);
}

static std::wstring get_text(HWND hwnd) {
    wchar_t buf[128]{};
    GetWindowTextW(hwnd, buf, 128);
    return buf;
}

static WORD parse_key(HWND hwnd, WORD fallback) {
    std::wstring s = get_text(hwnd);
    while (!s.empty() && iswspace(s.front())) s.erase(s.begin());
    while (!s.empty() && iswspace(s.back())) s.pop_back();
    if (s.empty()) return fallback;

    if (s.size() == 1) {
        wchar_t ch = towupper(s[0]);
        if ((ch >= L'A' && ch <= L'Z') || (ch >= L'0' && ch <= L'9')) {
            return static_cast<WORD>(ch);
        }
    }

    std::wstring u;
    for (wchar_t c : s) u.push_back(static_cast<wchar_t>(towupper(c)));

    if (u == L"SPACE") return VK_SPACE;
    if (u == L"ENTER") return VK_RETURN;
    if (u == L"TAB") return VK_TAB;
    if (u == L"SHIFT") return VK_SHIFT;
    if (u == L"CTRL" || u == L"CONTROL") return VK_CONTROL;
    if (u == L"ALT") return VK_MENU;
    if (u == L"ESC" || u == L"ESCAPE") return VK_ESCAPE;
    if (u == L"UP") return VK_UP;
    if (u == L"DOWN") return VK_DOWN;
    if (u == L"LEFT") return VK_LEFT;
    if (u == L"RIGHT") return VK_RIGHT;

    if (u.size() >= 2 && u[0] == L'F') {
        const int n = _wtoi(u.c_str() + 1);
        if (n >= 1 && n <= 24) return static_cast<WORD>(VK_F1 + n - 1);
    }

    return fallback;
}

static bool read_config_from_ui(Config& cfg) {
    cfg.capture_w = get_int(g_capture_w, DEFAULT_CAPTURE_W, 1, 800);
    cfg.capture_h = get_int(g_capture_h, DEFAULT_CAPTURE_H, 1, 800);
    cfg.r = get_int(g_target_r, DEFAULT_TARGET_R, 0, 255);
    cfg.g = get_int(g_target_g, DEFAULT_TARGET_G, 0, 255);
    cfg.b = get_int(g_target_b, DEFAULT_TARGET_B, 0, 255);
    cfg.tolerance = get_int(g_tolerance, DEFAULT_TOLERANCE, 0, 255);
    cfg.vk = parse_key(g_key, 'F');
    cfg.cooldown_ms = get_int(g_cooldown, DEFAULT_COOLDOWN_MS, 0, 60000);
    cfg.pre_min_ms = get_int(g_pre_min, DEFAULT_PRE_MIN_MS, 0, 10000);
    cfg.pre_max_ms = get_int(g_pre_max, DEFAULT_PRE_MAX_MS, 0, 10000);
    cfg.hold_min_ms = get_int(g_hold_min, DEFAULT_HOLD_MIN_MS, 0, 10000);
    cfg.hold_max_ms = get_int(g_hold_max, DEFAULT_HOLD_MAX_MS, 0, 10000);
    cfg.repeat_min_ms = get_int(g_repeat_min, DEFAULT_REPEAT_MIN_MS, 0, 10000);
    cfg.repeat_max_ms = get_int(g_repeat_max, DEFAULT_REPEAT_MAX_MS, 0, 10000);
    cfg.loop_min_ms = get_int(g_loop_min, DEFAULT_LOOP_MIN_MS, 0, 1000);
    cfg.loop_max_ms = get_int(g_loop_max, DEFAULT_LOOP_MAX_MS, 0, 1000);
    cfg.min_matching_pixels = get_int(g_min_pixels, DEFAULT_MIN_MATCHING_PIXELS, 1, 100000);
    cfg.primary_monitor = SendMessageW(g_primary, BM_GETCHECK, 0, 0) == BST_CHECKED;

    if (cfg.pre_max_ms < cfg.pre_min_ms) std::swap(cfg.pre_min_ms, cfg.pre_max_ms);
    if (cfg.hold_max_ms < cfg.hold_min_ms) std::swap(cfg.hold_min_ms, cfg.hold_max_ms);
    if (cfg.repeat_max_ms < cfg.repeat_min_ms) std::swap(cfg.repeat_min_ms, cfg.repeat_max_ms);
    if (cfg.loop_max_ms < cfg.loop_min_ms) std::swap(cfg.loop_min_ms, cfg.loop_max_ms);

    set_int(g_capture_w, cfg.capture_w);
    set_int(g_capture_h, cfg.capture_h);
    set_int(g_target_r, cfg.r);
    set_int(g_target_g, cfg.g);
    set_int(g_target_b, cfg.b);
    set_int(g_tolerance, cfg.tolerance);
    set_int(g_pre_min, cfg.pre_min_ms);
    set_int(g_pre_max, cfg.pre_max_ms);
    set_int(g_hold_min, cfg.hold_min_ms);
    set_int(g_hold_max, cfg.hold_max_ms);
    set_int(g_repeat_min, cfg.repeat_min_ms);
    set_int(g_repeat_max, cfg.repeat_max_ms);
    set_int(g_loop_min, cfg.loop_min_ms);
    set_int(g_loop_max, cfg.loop_max_ms);
    set_int(g_min_pixels, cfg.min_matching_pixels);

    return true;
}

static bool pixel_matches(uint8_t r, uint8_t g, uint8_t b, const Config& cfg) {
    return std::abs(static_cast<int>(r) - cfg.r) <= cfg.tolerance &&
           std::abs(static_cast<int>(g) - cfg.g) <= cfg.tolerance &&
           std::abs(static_cast<int>(b) - cfg.b) <= cfg.tolerance;
}

static bool contains_target_color(const uint8_t* pixels, int width, int height, const Config& cfg) {
    const int count = width * height;
    int matches = 0;

    for (int i = 0; i < count; ++i) {
        const uint8_t b = pixels[i * 4 + 0];
        const uint8_t g = pixels[i * 4 + 1];
        const uint8_t r = pixels[i * 4 + 2];
        if (pixel_matches(r, g, b, cfg) && ++matches >= cfg.min_matching_pixels) {
            return true;
        }
    }

    return false;
}

static void send_key(WORD vk, const Config& cfg, std::mt19937& rng) {
    std::this_thread::sleep_for(std::chrono::milliseconds(
        rand_range(rng, cfg.pre_min_ms, cfg.pre_max_ms)));

    INPUT down{};
    down.type = INPUT_KEYBOARD;
    down.ki.wVk = vk;
    SendInput(1, &down, sizeof(INPUT));

    std::this_thread::sleep_for(std::chrono::milliseconds(
        rand_range(rng, cfg.hold_min_ms, cfg.hold_max_ms)));

    INPUT up{};
    up.type = INPUT_KEYBOARD;
    up.ki.wVk = vk;
    up.ki.dwFlags = KEYEVENTF_KEYUP;
    SendInput(1, &up, sizeof(INPUT));
}

static Config current_config_copy() {
    std::lock_guard<std::mutex> lock(g_config_mutex);
    return g_config;
}

static void worker_loop() {
    std::random_device rd;
    std::mt19937 rng(rd());
    CaptureBuffer capture;
    int last_w = 0;
    int last_h = 0;

    using clock = std::chrono::steady_clock;
    auto next_allowed = clock::now();

    while (g_running.load(std::memory_order_relaxed)) {
        Config cfg = current_config_copy();

        if (cfg.capture_w != last_w || cfg.capture_h != last_h || !capture.pixels) {
            if (!capture.init(cfg.capture_w, cfg.capture_h)) {
                g_running.store(false);
                PostMessageW(g_main, WM_APP + 1, 0, 0);
                return;
            }
            last_w = cfg.capture_w;
            last_h = cfg.capture_h;
        }

        const int sx = cfg.primary_monitor ? 0 : GetSystemMetrics(SM_XVIRTUALSCREEN);
        const int sy = cfg.primary_monitor ? 0 : GetSystemMetrics(SM_YVIRTUALSCREEN);
        const int sw = cfg.primary_monitor ? GetSystemMetrics(SM_CXSCREEN) : GetSystemMetrics(SM_CXVIRTUALSCREEN);
        const int sh = cfg.primary_monitor ? GetSystemMetrics(SM_CYSCREEN) : GetSystemMetrics(SM_CYVIRTUALSCREEN);
        const int x = sx + (sw - cfg.capture_w) / 2;
        const int y = sy + (sh - cfg.capture_h) / 2;

        if (capture.capture(x, y) && contains_target_color(capture.pixels, cfg.capture_w, cfg.capture_h, cfg)) {
            const auto now = clock::now();
            if (now >= next_allowed) {
                send_key(cfg.vk, cfg, rng);
                const int extra = rand_range(rng, cfg.repeat_min_ms, cfg.repeat_max_ms);
                next_allowed = clock::now() + std::chrono::milliseconds(cfg.cooldown_ms + extra);
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(
            rand_range(rng, cfg.loop_min_ms, cfg.loop_max_ms)));
    }
}

static void set_running_ui(bool running) {
    EnableWindow(GetDlgItem(g_main, IDC_START), running ? FALSE : TRUE);
    EnableWindow(GetDlgItem(g_main, IDC_STOP), running ? TRUE : FALSE);
    set_text(g_status, running ? L"Status: running" : L"Status: stopped");
}

static void apply_config_from_ui() {
    Config cfg;
    read_config_from_ui(cfg);
    {
        std::lock_guard<std::mutex> lock(g_config_mutex);
        g_config = cfg;
    }
    InvalidateRect(g_preview, nullptr, TRUE);
}

static void start_worker() {
    if (g_running.load()) return;

    apply_config_from_ui();

    g_running.store(true);
    g_worker = std::thread(worker_loop);
    set_running_ui(true);
}

static void stop_worker() {
    g_running.store(false);
    if (g_worker.joinable()) g_worker.join();
    set_running_ui(false);
}

static HWND add_label(HWND parent, const wchar_t* text, int x, int y, int w, int h) {
    return CreateWindowExW(0, L"STATIC", text, WS_CHILD | WS_VISIBLE,
                           x, y, w, h, parent, nullptr, GetModuleHandleW(nullptr), nullptr);
}

static HWND add_edit(HWND parent, int id, int x, int y, int w, int h, int value) {
    HWND hwnd = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                                x, y, w, h, parent, reinterpret_cast<HMENU>(id), GetModuleHandleW(nullptr), nullptr);
    set_int(hwnd, value);
    return hwnd;
}

static HWND add_edit_text(HWND parent, int id, int x, int y, int w, int h, const wchar_t* text) {
    HWND hwnd = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", text, WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                                x, y, w, h, parent, reinterpret_cast<HMENU>(id), GetModuleHandleW(nullptr), nullptr);
    return hwnd;
}

static HWND add_button(HWND parent, int id, const wchar_t* text, int x, int y, int w, int h) {
    return CreateWindowExW(0, L"BUTTON", text, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                           x, y, w, h, parent, reinterpret_cast<HMENU>(id), GetModuleHandleW(nullptr), nullptr);
}

static void create_controls(HWND hwnd) {
    add_label(hwnd, L"Color Key Trigger", 16, 12, 220, 24);
    g_status = add_label(hwnd, L"Status: stopped", 350, 14, 180, 22);

    add_label(hwnd, L"Watch box size", 16, 52, 140, 20);
    add_label(hwnd, L"Width", 32, 80, 55, 20);
    g_capture_w = add_edit(hwnd, IDC_CAPTURE_W, 90, 76, 70, 24, DEFAULT_CAPTURE_W);
    add_label(hwnd, L"Height", 180, 80, 55, 20);
    g_capture_h = add_edit(hwnd, IDC_CAPTURE_H, 240, 76, 70, 24, DEFAULT_CAPTURE_H);
    g_primary = CreateWindowExW(0, L"BUTTON", L"Center on primary monitor",
                                WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
                                330, 77, 190, 24, hwnd, reinterpret_cast<HMENU>(IDC_PRIMARY),
                                GetModuleHandleW(nullptr), nullptr);
    SendMessageW(g_primary, BM_SETCHECK, BST_CHECKED, 0);

    add_label(hwnd, L"Target color", 16, 120, 140, 20);
    add_label(hwnd, L"R", 32, 148, 20, 20);
    g_target_r = add_edit(hwnd, IDC_TARGET_R, 55, 144, 55, 24, DEFAULT_TARGET_R);
    add_label(hwnd, L"G", 122, 148, 20, 20);
    g_target_g = add_edit(hwnd, IDC_TARGET_G, 145, 144, 55, 24, DEFAULT_TARGET_G);
    add_label(hwnd, L"B", 212, 148, 20, 20);
    g_target_b = add_edit(hwnd, IDC_TARGET_B, 235, 144, 55, 24, DEFAULT_TARGET_B);
    add_label(hwnd, L"Tolerance", 310, 148, 70, 20);
    g_tolerance = add_edit(hwnd, IDC_TOLERANCE, 385, 144, 55, 24, DEFAULT_TOLERANCE);
    add_button(hwnd, IDC_COLOR_PICKER, L"Pick Color", 455, 142, 86, 28);
    g_preview = CreateWindowExW(WS_EX_CLIENTEDGE, L"STATIC", L"", WS_CHILD | WS_VISIBLE,
                                555, 143, 36, 26, hwnd, reinterpret_cast<HMENU>(IDC_PREVIEW),
                                GetModuleHandleW(nullptr), nullptr);

    add_label(hwnd, L"Keyboard key", 16, 188, 140, 20);
    add_label(hwnd, L"Key", 32, 216, 40, 20);
    g_key = add_edit_text(hwnd, IDC_KEY, 90, 212, 90, 24, DEFAULT_KEY);
    add_label(hwnd, L"Examples: F, SPACE, ENTER, SHIFT, CTRL, ALT, F1", 200, 216, 360, 20);

    add_label(hwnd, L"Timing", 16, 256, 140, 20);
    add_label(hwnd, L"Cooldown ms", 32, 284, 100, 20);
    g_cooldown = add_edit(hwnd, IDC_COOLDOWN, 140, 280, 70, 24, DEFAULT_COOLDOWN_MS);
    add_label(hwnd, L"Matching pixels", 250, 284, 110, 20);
    g_min_pixels = add_edit(hwnd, IDC_MIN_PIXELS, 365, 280, 70, 24, DEFAULT_MIN_MATCHING_PIXELS);

    add_label(hwnd, L"Before press ms", 32, 324, 110, 20);
    g_pre_min = add_edit(hwnd, IDC_PRE_MIN, 150, 320, 70, 24, DEFAULT_PRE_MIN_MS);
    add_label(hwnd, L"to", 228, 324, 22, 20);
    g_pre_max = add_edit(hwnd, IDC_PRE_MAX, 255, 320, 70, 24, DEFAULT_PRE_MAX_MS);

    add_label(hwnd, L"Hold key ms", 32, 364, 110, 20);
    g_hold_min = add_edit(hwnd, IDC_HOLD_MIN, 150, 360, 70, 24, DEFAULT_HOLD_MIN_MS);
    add_label(hwnd, L"to", 228, 364, 22, 20);
    g_hold_max = add_edit(hwnd, IDC_HOLD_MAX, 255, 360, 70, 24, DEFAULT_HOLD_MAX_MS);

    add_label(hwnd, L"Extra wait ms", 32, 404, 110, 20);
    g_repeat_min = add_edit(hwnd, IDC_REPEAT_MIN, 150, 400, 70, 24, DEFAULT_REPEAT_MIN_MS);
    add_label(hwnd, L"to", 228, 404, 22, 20);
    g_repeat_max = add_edit(hwnd, IDC_REPEAT_MAX, 255, 400, 70, 24, DEFAULT_REPEAT_MAX_MS);

    add_label(hwnd, L"Scan sleep ms", 32, 444, 110, 20);
    g_loop_min = add_edit(hwnd, IDC_LOOP_MIN, 150, 440, 70, 24, DEFAULT_LOOP_MIN_MS);
    add_label(hwnd, L"to", 228, 444, 22, 20);
    g_loop_max = add_edit(hwnd, IDC_LOOP_MAX, 255, 440, 70, 24, DEFAULT_LOOP_MAX_MS);

    add_button(hwnd, IDC_APPLY, L"Apply", 350, 422, 80, 36);
    add_button(hwnd, IDC_START, L"Start", 440, 422, 70, 36);
    add_button(hwnd, IDC_STOP, L"Stop", 520, 422, 70, 36);
    EnableWindow(GetDlgItem(hwnd, IDC_STOP), FALSE);
}

static void choose_color(HWND hwnd) {
    Config cfg;
    read_config_from_ui(cfg);

    static COLORREF custom_colors[16]{};
    CHOOSECOLORW cc{};
    cc.lStructSize = sizeof(cc);
    cc.hwndOwner = hwnd;
    cc.rgbResult = RGB(cfg.r, cfg.g, cfg.b);
    cc.lpCustColors = custom_colors;
    cc.Flags = CC_FULLOPEN | CC_RGBINIT;

    if (ChooseColorW(&cc)) {
        set_int(g_target_r, GetRValue(cc.rgbResult));
        set_int(g_target_g, GetGValue(cc.rgbResult));
        set_int(g_target_b, GetBValue(cc.rgbResult));
        InvalidateRect(g_preview, nullptr, TRUE);
    }
}

static LRESULT CALLBACK window_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    switch (msg) {
    case WM_CREATE:
        create_controls(hwnd);
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wparam)) {
        case IDC_START:
            start_worker();
            return 0;
        case IDC_STOP:
            stop_worker();
            return 0;
        case IDC_APPLY:
            apply_config_from_ui();
            set_text(g_status, g_running.load() ? L"Status: running" : L"Status: stopped");
            return 0;
        case IDC_COLOR_PICKER:
            choose_color(hwnd);
            return 0;
        case IDC_TARGET_R:
        case IDC_TARGET_G:
        case IDC_TARGET_B:
            if (HIWORD(wparam) == EN_CHANGE) InvalidateRect(g_preview, nullptr, TRUE);
            return 0;
        }
        break;

    case WM_CTLCOLORSTATIC:
        if (reinterpret_cast<HWND>(lparam) == g_preview) {
            if (g_preview_brush) DeleteObject(g_preview_brush);
            const int r = get_int(g_target_r, DEFAULT_TARGET_R, 0, 255);
            const int g = get_int(g_target_g, DEFAULT_TARGET_G, 0, 255);
            const int b = get_int(g_target_b, DEFAULT_TARGET_B, 0, 255);
            g_preview_brush = CreateSolidBrush(RGB(r, g, b));
            return reinterpret_cast<LRESULT>(g_preview_brush);
        }
        break;

    case WM_APP + 1:
        stop_worker();
        MessageBoxW(hwnd, L"Screen capture could not start.", L"Color Key Trigger", MB_ICONERROR);
        return 0;

    case WM_CLOSE:
        stop_worker();
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        stop_worker();
        if (g_preview_brush) {
            DeleteObject(g_preview_brush);
            g_preview_brush = nullptr;
        }
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProcW(hwnd, msg, wparam, lparam);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show_cmd) {
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    const wchar_t class_name[] = L"ColorTriggerGuiWindow";

    WNDCLASSW wc{};
    wc.lpfnWndProc = window_proc;
    wc.hInstance = instance;
    wc.lpszClassName = class_name;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);

    if (!RegisterClassW(&wc)) return 1;

    g_main = CreateWindowExW(0, class_name, L"Color Key Trigger",
                             WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
                             CW_USEDEFAULT, CW_USEDEFAULT, 625, 525,
                             nullptr, nullptr, instance, nullptr);
    if (!g_main) return 1;

    ShowWindow(g_main, show_cmd);
    UpdateWindow(g_main);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return 0;
}
